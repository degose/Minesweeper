import { combineReducers } from 'redux';
import Mines from './reducer-mines';

const rootReducer = combineReducers({
  Mines
});

export default rootReducer;