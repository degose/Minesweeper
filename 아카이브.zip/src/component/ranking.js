import React, { Component } from 'react';

class Ranking extends Component {
  render(){
    return (
      <section>
        <h2>랭킹영역</h2>
        <table>
          <tr>
            <th>순위</th>
            <th>이름</th>
          </tr>
          <tr>
            <td>1</td>
            <td>이름</td>
          </tr>
        </table>
      </section>
    )
  }
}

export default Ranking;