import React, { Component} from 'react';

export default class GameArea extends Component {
  // constructor(props) {
  //   super(props);
  // }

  renderList() {
    // 리액트 뷰와 리덕스 스테이트를 합쳐주는 것
    console.log('spanArray::',this.props.spanArray);
    // return this.props.spanArray.map((span) => {
    //   return (
    //     <span id='"+i+""+j+"' data-row='"+i+"' data-col='"+j+"' class='box first'></span>
    //   );
    // });
  }

  render(){
    return (
      <div id="container">
        <h1>나오니</h1>
        <div>이거는 :{this.renderList()}</div>
      </div>
    )
  }
}
